//Swap two numbers using temporary variable
#include <iostream>

using namespace std;

int main() {
    
    int a = 5, b = 10, temp;
    
    cout << "Before swapping the numbers." <<endl;
    cout << "a = " << a << ", b = " << b << endl;
    
    temp = a;
    a = b;
    b = temp;
    
    cout << "\nAfter swapping the numbers." << endl;
    cout << "a = " << a << ", b = " << b << endl;

    return 0;
}
